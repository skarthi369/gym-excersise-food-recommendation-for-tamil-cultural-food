
import React from 'react';
import Header from '@/components/Header';
import ProfileForm from '@/components/ProfileForm';

const ProfilePage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <ProfileForm />
      </main>
    </div>
  );
};

export default ProfilePage;
