import { Food, Workout, UserProfile } from './models';
import { foods } from './foods';
import { workouts } from './workouts';

interface UserPreferences {
  favoriteFood: number[];
  completedWorkouts: number[];
  dietaryRestrictions: string[];
  healthConditions: string[];
  fitnessProgress: {
    weight: number[];
    dates: string[];
  };
  workoutPreferences: {
    preferredTime: string;
    preferredDuration: number;
    preferredIntensity: string;
  };
}

interface RecommendationScore {
  itemId: number;
  score: number;
  reason: string;
}

export class MLRecommendationEngine {
  private userProfile: UserProfile;
  private userPreferences: UserPreferences;

  constructor(userProfile: UserProfile, userPreferences: UserPreferences) {
    this.userProfile = userProfile;
    this.userPreferences = userPreferences;
  }

  // Collaborative Filtering: Find similar users and their preferences
  private findSimilarUsers(currentUser: UserPreferences): number[] {
    // Simulated similarity scoring based on user preferences
    // In a real implementation, this would use ML algorithms like cosine similarity
    return [1, 2, 3]; // Sample similar user IDs
  }

  // Content-Based Filtering for Foods
  private calculateFoodScore(food: Food): RecommendationScore {
    let score = 0;
    const reasons: string[] = [];

    // Check if food matches user's fitness goal
    if (food.suitableFor.includes(this.userProfile.goal)) {
      score += 0.3;
      reasons.push(`Matches your ${this.userProfile.goal} goal`);
    }

    // Check dietary preferences
    if (this.userProfile.foodPreference === 'vegetarian' && food.isVegetarian) {
      score += 0.2;
      reasons.push('Matches your vegetarian preference');
    }

    // Check if food is in user's favorites
    if (this.userPreferences.favoriteFood.includes(food.id)) {
      score += 0.15;
      reasons.push('Based on your favorites');
    }

    // Nutritional alignment with goals
    if (this.userProfile.goal === 'bulking' && food.protein > 20) {
      score += 0.2;
      reasons.push('High protein content for muscle building');
    }
    if (this.userProfile.goal === 'cutting' && food.calories < 300) {
      score += 0.2;
      reasons.push('Low calorie option for weight loss');
    }

    return {
      itemId: food.id,
      score,
      reason: reasons.join(', ')
    };
  }

  // Content-Based Filtering for Workouts
  private calculateWorkoutScore(workout: Workout): RecommendationScore {
    let score = 0;
    const reasons: string[] = [];

    // Match workout level with user's fitness level
    if (workout.level.includes(this.userProfile.fitnessLevel)) {
      score += 0.3;
      reasons.push(`Matches your ${this.userProfile.fitnessLevel} fitness level`);
    }

    // Check if workout aligns with fitness goal
    if (workout.suitableFor.includes(this.userProfile.goal)) {
      score += 0.25;
      reasons.push(`Suitable for your ${this.userProfile.goal} goal`);
    }

    // Consider workout duration preferences
    if (workout.duration <= this.userPreferences.workoutPreferences.preferredDuration) {
      score += 0.2;
      reasons.push('Fits your preferred workout duration');
    }

    // Avoid recently completed workouts for variety
    if (!this.userPreferences.completedWorkouts.includes(workout.id)) {
      score += 0.15;
      reasons.push('New workout for variety');
    }

    return {
      itemId: workout.id,
      score,
      reason: reasons.join(', ')
    };
  }

  // Get Personalized Food Recommendations
  public getPersonalizedMealPlan(): Food[] {
    const scoredFoods = foods.map(food => ({
      food,
      ...this.calculateFoodScore(food)
    }));

    // Sort by score and get top recommendations
    return scoredFoods
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)
      .map(item => item.food);
  }

  // Get Personalized Workout Recommendations
  public getPersonalizedWorkoutPlan(): Workout[] {
    const scoredWorkouts = workouts.map(workout => ({
      workout,
      ...this.calculateWorkoutScore(workout)
    }));

    // Sort by score and get top recommendations
    return scoredWorkouts
      .sort((a, b) => b.score - a.score)
      .slice(0, 3)
      .map(item => item.workout);
  }

  // Dynamic Difficulty Adjustment
  public adjustWorkoutIntensity(userProgress: number): void {
    // Analyze user's progress and adjust workout parameters
    if (userProgress > 0.8) {
      // Increase difficulty
      this.userProfile.fitnessLevel = 'advanced';
    } else if (userProgress < 0.4) {
      // Decrease difficulty
      this.userProfile.fitnessLevel = 'beginner';
    }
  }

  // Predict User's Progress
  public predictProgress(weeks: number): {
    predictedWeight: number;
    predictedStrength: number;
  } {
    // Simple linear regression for progress prediction
    // In a real implementation, this would use more sophisticated ML models
    const weightHistory = this.userPreferences.fitnessProgress.weight;
    const weeklyChange = weightHistory.length > 1 
      ? (weightHistory[weightHistory.length - 1] - weightHistory[0]) / weightHistory.length 
      : 0;

    return {
      predictedWeight: weightHistory[weightHistory.length - 1] + (weeklyChange * weeks),
      predictedStrength: 0.1 * weeks // Simplified strength increase prediction
    };
  }
} 