
// User profile types
export type FitnessGoal = 'bulking' | 'cutting';
export type FoodPreference = 'vegetarian' | 'non-vegetarian' | 'eggetarian';
export type FitnessLevel = 'beginner' | 'intermediate' | 'advanced';

export interface UserProfile {
  goal: FitnessGoal;
  foodPreference: FoodPreference;
  fitnessLevel: FitnessLevel;
  scheduleDuration: number; // in days
}

// Food types
export interface Food {
  id: number;
  name: string;
  type: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  imageUrl: string;
  description: string;
  ingredients: string[];
  suitableFor: FitnessGoal[];
  isVegetarian: boolean;
  isEggitarian: boolean;
}

// Workout types
export interface Workout {
  id: number;
  name: string;
  muscleGroup: string;
  level: FitnessLevel[];
  instructions: string[];
  imageUrl: string;
  suitableFor: FitnessGoal[];
  duration: number; // in minutes
  sets: number;
  reps: number;
}

// Daily plan types
export interface DailyMeal {
  breakfast: Food[];
  lunch: Food[];
  dinner: Food[];
  snacks: Food[];
}

export interface DailyPlan {
  day: number;
  meals: DailyMeal;
  workouts: Workout[];
}
