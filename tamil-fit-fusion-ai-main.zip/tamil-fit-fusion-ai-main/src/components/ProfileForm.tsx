
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@/context/UserContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';

const ProfileForm: React.FC = () => {
  const { userProfile, updateProfile, generatePlans } = useUser();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    goal: userProfile?.goal || 'bulking',
    foodPreference: userProfile?.foodPreference || 'vegetarian',
    fitnessLevel: userProfile?.fitnessLevel || 'beginner',
    scheduleDuration: userProfile?.scheduleDuration || 30
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile(formData);
    generatePlans();
    toast.success('Profile updated successfully!');
    navigate('/plans');
  };

  const handleDurationChange = (value: number[]) => {
    setFormData({ ...formData, scheduleDuration: value[0] });
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-lg mx-auto py-8 px-4">
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">Your Fitness Profile</CardTitle>
          <CardDescription className="text-center">
            Tell us about your fitness goals and preferences
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">What is your fitness goal?</h3>
            <RadioGroup
              value={formData.goal}
              onValueChange={(value) => setFormData({ ...formData, goal: value as 'bulking' | 'cutting' })}
              className="grid grid-cols-2 gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="bulking" id="bulking" />
                <Label htmlFor="bulking" className="cursor-pointer">
                  <div className="flex flex-col">
                    <span className="font-medium">Bulking</span>
                    <span className="text-sm text-gray-500">Gain muscle mass</span>
                  </div>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="cutting" id="cutting" />
                <Label htmlFor="cutting" className="cursor-pointer">
                  <div className="flex flex-col">
                    <span className="font-medium">Cutting</span>
                    <span className="text-sm text-gray-500">Lose fat, retain muscle</span>
                  </div>
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">What are your food preferences?</h3>
            <RadioGroup
              value={formData.foodPreference}
              onValueChange={(value) => 
                setFormData({ 
                  ...formData, 
                  foodPreference: value as 'vegetarian' | 'non-vegetarian' | 'eggetarian' 
                })
              }
              className="grid grid-cols-1 gap-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="vegetarian" id="vegetarian" />
                <Label htmlFor="vegetarian" className="cursor-pointer">Vegetarian</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="eggetarian" id="eggetarian" />
                <Label htmlFor="eggetarian" className="cursor-pointer">Eggetarian</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="non-vegetarian" id="non-vegetarian" />
                <Label htmlFor="non-vegetarian" className="cursor-pointer">Non-Vegetarian</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">What is your fitness level?</h3>
            <RadioGroup
              value={formData.fitnessLevel}
              onValueChange={(value) => 
                setFormData({ 
                  ...formData, 
                  fitnessLevel: value as 'beginner' | 'intermediate' | 'advanced' 
                })
              }
              className="grid grid-cols-1 gap-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="beginner" id="beginner" />
                <Label htmlFor="beginner" className="cursor-pointer">Beginner</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="intermediate" id="intermediate" />
                <Label htmlFor="intermediate" className="cursor-pointer">Intermediate</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="advanced" id="advanced" />
                <Label htmlFor="advanced" className="cursor-pointer">Advanced</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between">
              <h3 className="text-lg font-medium">Plan Duration</h3>
              <span className="text-sm font-medium">{formData.scheduleDuration} days</span>
            </div>
            <Slider
              defaultValue={[formData.scheduleDuration]}
              min={7}
              max={90}
              step={1}
              onValueChange={handleDurationChange}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-gray-500">
              <span>7 days</span>
              <span>90 days</span>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full tamil-gradient">
            Save and Generate Plan
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
};

export default ProfileForm;
