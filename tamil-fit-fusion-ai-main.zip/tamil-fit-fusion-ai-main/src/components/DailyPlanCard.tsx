import React from 'react';
import { DailyPlan } from '@/data/models';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import FoodCard from './FoodCard';
import WorkoutCard from './WorkoutCard';

interface DailyPlanCardProps {
  plan: DailyPlan;
}

const DailyPlanCard: React.FC<DailyPlanCardProps> = ({ plan }) => {
  // Ensure all meal arrays exist with proper null checks
  const breakfast = plan?.meals?.breakfast ?? [];
  const lunch = plan?.meals?.lunch ?? [];
  const dinner = plan?.meals?.dinner ?? [];
  const snacks = plan?.meals?.snacks ?? [];
  
  // Calculate total calories and macros for the day with proper null handling
  const calculateTotal = (foods: any[], property: string) => {
    return foods
      .filter(food => food && food[property] !== undefined)
      .reduce((sum, food) => sum + food[property], 0);
  };

  const allFoods = [...breakfast, ...lunch, ...dinner, ...snacks].filter(Boolean);
  
  const totalCalories = calculateTotal(allFoods, 'calories');
  const totalProtein = calculateTotal(allFoods, 'protein');
  const totalCarbs = calculateTotal(allFoods, 'carbs');
  const totalFats = calculateTotal(allFoods, 'fats');

  return (
    <Card className="w-full mb-6">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Day {plan.day}</span>
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-flame text-orange-500"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"></path></svg>
            <span className="text-sm font-normal">{totalCalories} kcal</span>
          </div>
        </CardTitle>
        <CardDescription>
          <div className="flex justify-between text-xs">
            <span>P: {totalProtein}g</span>
            <span>C: {totalCarbs}g</span>
            <span>F: {totalFats}g</span>
          </div>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="meals">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="meals">Meals</TabsTrigger>
            <TabsTrigger value="workouts">Workouts</TabsTrigger>
          </TabsList>
          <TabsContent value="meals" className="pt-4">
            <div className="space-y-4">
              {breakfast.length > 0 && (
                <div>
                  <h3 className="font-medium text-sm mb-2">Breakfast</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {breakfast.map(food => food && (
                      <FoodCard key={food.id} food={food} mealType="breakfast" />
                    ))}
                  </div>
                </div>
              )}
              
              {lunch.length > 0 && (
                <div>
                  <h3 className="font-medium text-sm mb-2">Lunch</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {lunch.map(food => food && (
                      <FoodCard key={food.id} food={food} mealType="lunch" />
                    ))}
                  </div>
                </div>
              )}
              
              {dinner.length > 0 && (
                <div>
                  <h3 className="font-medium text-sm mb-2">Dinner</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {dinner.map(food => food && (
                      <FoodCard key={food.id} food={food} mealType="dinner" />
                    ))}
                  </div>
                </div>
              )}
              
              {snacks.length > 0 && (
                <div>
                  <h3 className="font-medium text-sm mb-2">Snacks</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {snacks.map(food => food && (
                      <FoodCard key={food.id} food={food} mealType="snack" />
                    ))}
                  </div>
                </div>
              )}
              
              {!allFoods.length && (
                <p className="text-center text-gray-500 py-4">No meals found for this day.</p>
              )}
            </div>
          </TabsContent>
          <TabsContent value="workouts" className="pt-4">
            {plan.workouts && plan.workouts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {plan.workouts.map(workout => workout && (
                  <WorkoutCard key={workout.id} workout={workout} />
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 py-4">No workouts found for this day.</p>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default DailyPlanCard;
