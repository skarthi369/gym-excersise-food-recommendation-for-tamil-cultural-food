import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useUser } from '@/context/UserContext';
import { MLRecommendationEngine } from '@/data/recommendations';
import { Food, Workout } from '@/data/models';

const RecommendationCard: React.FC = () => {
  const { userProfile } = useUser();
  const [recommendations, setRecommendations] = React.useState<{
    foods: Food[];
    workouts: Workout[];
    predictedProgress: {
      predictedWeight: number;
      predictedStrength: number;
    };
  }>({
    foods: [],
    workouts: [],
    predictedProgress: {
      predictedWeight: 0,
      predictedStrength: 0
    }
  });

  React.useEffect(() => {
    if (userProfile) {
      // Sample user preferences (in a real app, this would come from user data)
      const userPreferences = {
        favoriteFood: [1, 3, 5],
        completedWorkouts: [2, 4],
        dietaryRestrictions: [],
        healthConditions: [],
        fitnessProgress: {
          weight: [75, 74, 73.5, 73], // Sample weight history in kg
          dates: ['2024-01-01', '2024-01-08', '2024-01-15', '2024-01-22']
        },
        workoutPreferences: {
          preferredTime: 'morning',
          preferredDuration: 45,
          preferredIntensity: 'moderate'
        }
      };

      const mlEngine = new MLRecommendationEngine(userProfile, userPreferences);
      
      setRecommendations({
        foods: mlEngine.getPersonalizedMealPlan(),
        workouts: mlEngine.getPersonalizedWorkoutPlan(),
        predictedProgress: mlEngine.predictProgress(4) // Predict progress for next 4 weeks
      });
    }
  }, [userProfile]);

  return (
    <Card className="w-full mb-6">
      <CardHeader>
        <CardTitle>AI-Powered Recommendations</CardTitle>
        <CardDescription>
          Personalized suggestions based on your profile and progress
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Food Recommendations */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Recommended Foods</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recommendations.foods.map(food => (
                <div key={food.id} className="bg-secondary/10 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">{food.name}</h4>
                    <Badge variant="secondary">{food.type}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{food.description}</p>
                  <div className="flex items-center gap-2 text-xs">
                    <span>🔥 {food.calories} kcal</span>
                    <span>🥩 {food.protein}g protein</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Workout Recommendations */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Recommended Workouts</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recommendations.workouts.map(workout => (
                <div key={workout.id} className="bg-primary/10 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">{workout.name}</h4>
                    <Badge>{workout.level[0]}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{workout.muscleGroup}</p>
                  <div className="flex items-center gap-2 text-xs">
                    <span>⏱️ {workout.duration} min</span>
                    <span>🔄 {workout.sets} x {workout.reps}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Progress Prediction */}
          <div className="bg-accent/10 p-4 rounded-lg">
            <h3 className="text-lg font-semibold mb-3">4-Week Progress Prediction</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Predicted Weight</p>
                <p className="text-2xl font-semibold">
                  {recommendations.predictedProgress.predictedWeight.toFixed(1)} kg
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Strength Improvement</p>
                <p className="text-2xl font-semibold">
                  +{(recommendations.predictedProgress.predictedStrength * 100).toFixed(0)}%
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RecommendationCard; 