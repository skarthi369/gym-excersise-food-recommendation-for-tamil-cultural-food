import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import { useUser } from '@/context/UserContext';
import DailyPlanCard from '@/components/DailyPlanCard';
import { Button } from '@/components/ui/button';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';
import RecommendationCard from '@/components/RecommendationCard';

const PlansPage: React.FC = () => {
  const { userProfile, dailyPlans, isProfileComplete } = useUser();
  const navigate = useNavigate();
  
  const [currentPage, setCurrentPage] = useState(1);
  const plansPerPage = 5;
  
  // Redirect to profile if not complete
  React.useEffect(() => {
    if (!isProfileComplete) {
      navigate('/profile');
    }
  }, [isProfileComplete, navigate]);
  
  const [currentPlans, setCurrentPlans] = React.useState(dailyPlans);

  React.useEffect(() => {
    setCurrentPlans(dailyPlans);
  }, [dailyPlans]);
  
  if (!userProfile || dailyPlans.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center p-8">
            <h2 className="text-2xl font-bold mb-4">No Plan Generated Yet</h2>
            <p className="mb-6 text-gray-600">Please complete your profile to generate a personalized plan.</p>
            <Button onClick={() => navigate('/profile')} className="tamil-gradient">
              Create Profile
            </Button>
          </div>
        </main>
      </div>
    );
  }
  
  // Calculate pagination
  const indexOfLastPlan = currentPage * plansPerPage;
  const indexOfFirstPlan = indexOfLastPlan - plansPerPage;
  const currentPlansPage = dailyPlans.slice(indexOfFirstPlan, indexOfLastPlan);
  const totalPages = Math.ceil(dailyPlans.length / plansPerPage);
  
  const paginate = (pageNumber: number) => setCurrentPage(pageNumber);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-2xl font-bold">Your {userProfile.goal === 'bulking' ? 'Bulking' : 'Cutting'} Plan</h1>
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <span>{userProfile.foodPreference}</span>
              <span>•</span>
              <span>{userProfile.fitnessLevel}</span>
              <span>•</span>
              <span>{userProfile.scheduleDuration} days</span>
            </div>
          </div>
          
          {/* AI Recommendations */}
          <RecommendationCard />
          
          <div className="space-y-6">
            {currentPlansPage.map(plan => (
              <DailyPlanCard key={plan.day} plan={plan} />
            ))}
          </div>
          
          {totalPages > 1 && (
            <Pagination className="mt-8">
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    onClick={() => paginate(Math.max(currentPage - 1, 1))}
                    className={currentPage === 1 ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
                  />
                </PaginationItem>
                
                {Array.from({ length: totalPages }).map((_, i) => (
                  <PaginationItem key={i}>
                    <PaginationLink
                      onClick={() => paginate(i + 1)}
                      isActive={currentPage === i + 1}
                      className="cursor-pointer"
                    >
                      {i + 1}
                    </PaginationLink>
                  </PaginationItem>
                ))}
                
                <PaginationItem>
                  <PaginationNext 
                    onClick={() => paginate(Math.min(currentPage + 1, totalPages))}
                    className={currentPage === totalPages ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
          
          <div className="mt-8 text-center">
            <Button 
              variant="outline" 
              onClick={() => navigate('/profile')}
              className="text-tamil-purple-600 border-tamil-purple-600 hover:bg-tamil-purple-50"
            >
              Edit Profile
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PlansPage;
