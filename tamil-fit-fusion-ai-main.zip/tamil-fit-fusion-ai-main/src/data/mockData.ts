import { DailyPlan } from './models';
import { foods } from './foods';
import { workouts } from './workouts';

export { foods } from './foods';
export { workouts } from './workouts';

// Generate sample daily plans
export const generateSamplePlans = (
  goal: 'bulking' | 'cutting', 
  foodPreference: 'vegetarian' | 'non-vegetarian' | 'eggetarian',
  days: number = 7
): DailyPlan[] => {
  const filteredFoods = foods.filter(food => {
    if (foodPreference === 'vegetarian' && !food.isVegetarian) return false;
    if (foodPreference === 'eggetarian' && !food.isEggitarian) return false;
    return food.suitableFor.includes(goal);
  });

  const breakfastOptions = filteredFoods.filter(food => food.type === 'breakfast');
  const lunchOptions = filteredFoods.filter(food => food.type === 'lunch');
  const dinnerOptions = filteredFoods.filter(food => food.type === 'dinner');
  const snackOptions = filteredFoods.filter(food => food.type === 'snack');

  const filteredWorkouts = workouts.filter(workout => workout.suitableFor.includes(goal));

  const plans: DailyPlan[] = [];

  // Handle edge case where no foods match the criteria
  if (filteredFoods.length === 0) {
    console.warn('No foods match the criteria. Check food data or user preferences.');
    // Return empty plans to avoid errors
    return Array(days).fill(null).map((_, index) => ({
      day: index + 1,
      meals: {
        breakfast: [],
        lunch: [],
        dinner: [],
        snacks: []
      },
      workouts: []
    }));
  }

  // Ensure we have at least one option for each meal type
  const safeBreakfastOptions = breakfastOptions.length > 0 ? breakfastOptions : [filteredFoods[0]];
  const safeLunchOptions = lunchOptions.length > 0 ? lunchOptions : [filteredFoods[0]];
  const safeDinnerOptions = dinnerOptions.length > 0 ? dinnerOptions : [filteredFoods[0]];
  const safeSnackOptions = snackOptions.length > 0 ? snackOptions : [filteredFoods[0]];

  for (let day = 1; day <= days; day++) {
    // Safe selection logic to prevent undefined values
    const breakfast = [safeBreakfastOptions[day % safeBreakfastOptions.length]];
    const lunch = [safeLunchOptions[day % safeLunchOptions.length]];
    const dinner = [safeDinnerOptions[day % safeDinnerOptions.length]];
    const snacks = safeSnackOptions.length > 0 ? [safeSnackOptions[day % safeSnackOptions.length]] : [];

    // Select 2-3 workouts per day, ensuring we don't exceed the array length
    const workoutCount = Math.min(filteredWorkouts.length, 2);
    const startIdx = day % filteredWorkouts.length;
    const dayWorkouts = workoutCount > 0 
      ? filteredWorkouts.slice(startIdx, startIdx + workoutCount)
      : [];

    plans.push({
      day,
      meals: {
        breakfast,
        lunch,
        dinner,
        snacks
      },
      workouts: dayWorkouts
    });
  }

  return plans;
};
