
import React from 'react';
import { Workout } from '@/data/models';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface WorkoutCardProps {
  workout: Workout;
}

const WorkoutCard: React.FC<WorkoutCardProps> = ({ workout }) => {
  const fallbackImage = 'https://images.unsplash.com/photo-1487252665478-49b61b47f302';

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card className="workout-card hover:scale-in cursor-pointer overflow-hidden hover:shadow-md transition-all">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-lg">{workout.name}</CardTitle>
            <CardDescription className="text-sm">{workout.muscleGroup}</CardDescription>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="aspect-video w-full bg-gray-100 rounded-md mb-4 overflow-hidden">
              <img 
                src={workout.imageUrl || fallbackImage}
                alt={workout.name}
                className="w-full h-full object-cover transition-transform hover:scale-105"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = fallbackImage;
                }}
              />
            </div>
            <div className="flex flex-col space-y-2">
              <div className="flex justify-between text-sm">
                <span>Duration:</span>
                <span className="font-medium">{workout.duration} min</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Sets x Reps:</span>
                <span className="font-medium">{workout.sets} x {workout.reps}</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="p-4 pt-0 flex justify-between items-center">
            <Badge variant="outline" className="text-xs capitalize">
              {workout.level.join(', ')}
            </Badge>
            <Badge variant="secondary" className="text-xs capitalize">
              {workout.suitableFor.join(', ')}
            </Badge>
          </CardFooter>
        </Card>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{workout.name}</DialogTitle>
          <DialogDescription>{workout.muscleGroup}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="aspect-video w-full bg-gray-100 rounded-md overflow-hidden">
            <img 
              src={workout.imageUrl || fallbackImage}
              alt={workout.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = fallbackImage;
              }}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-3 rounded-md">
              <p className="text-xs text-gray-500">Duration</p>
              <p className="font-medium">{workout.duration} min</p>
            </div>
            <div className="bg-gray-50 p-3 rounded-md">
              <p className="text-xs text-gray-500">Sets x Reps</p>
              <p className="font-medium">{workout.sets} x {workout.reps}</p>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium mb-2">Instructions</h3>
            <ol className="list-decimal list-inside text-sm text-gray-600 space-y-2">
              {workout.instructions.map((instruction, index) => (
                <li key={index}>{instruction}</li>
              ))}
            </ol>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="capitalize">
              {workout.level.join(', ')}
            </Badge>
            <Badge variant="secondary" className="capitalize">
              {workout.suitableFor.join(', ')}
            </Badge>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default WorkoutCard;

