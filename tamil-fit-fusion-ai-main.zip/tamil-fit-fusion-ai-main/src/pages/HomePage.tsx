
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useUser } from '@/context/UserContext';
import Header from '@/components/Header';

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { isProfileComplete } = useUser();

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h1 className="text-4xl md:text-5xl font-bold">
            <span className="text-tamil-purple-600">Tamil</span> Fit{' '}
            <span className="text-tamil-green-600">Fusion</span>
          </h1>
          
          <p className="text-xl text-gray-600">
            Personalized meal and workout plans blending traditional Tamil cuisine with modern fitness goals.
          </p>
          
          <div className="mt-8 flex justify-center">
            <Button
              onClick={() => navigate(isProfileComplete ? '/plans' : '/profile')}
              className="tamil-gradient text-white px-8 py-6 text-lg rounded-full"
            >
              {isProfileComplete ? 'View Your Plan' : 'Get Started'}
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="w-12 h-12 mb-4 bg-tamil-purple-100 rounded-full flex items-center justify-center mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-utensils text-tamil-purple-600"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"></path><path d="M7 2v20"></path><path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"></path></svg>
              </div>
              <h3 className="text-lg font-semibold text-center mb-2">
                Tamil Cuisine
              </h3>
              <p className="text-gray-600 text-center">
                Enjoy delicious, nutritious traditional Tamil meals tailored to your fitness goals.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="w-12 h-12 mb-4 bg-tamil-green-100 rounded-full flex items-center justify-center mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-dumbbell text-tamil-green-600"><path d="m6.5 6.5 11 11"></path><path d="m21 21-1-1"></path><path d="m3 3 1 1"></path><path d="m18 22 4-4"></path><path d="m2 6 4-4"></path><path d="m3 10 7-7"></path><path d="m14 21 7-7"></path></svg>
              </div>
              <h3 className="text-lg font-semibold text-center mb-2">
                Custom Workouts
              </h3>
              <p className="text-gray-600 text-center">
                Get workout plans designed for bulking or cutting, matched to your experience level.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="w-12 h-12 mb-4 bg-tamil-purple-100 rounded-full flex items-center justify-center mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-calendar-check text-tamil-purple-600"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"></rect><line x1="16" x2="16" y1="2" y2="6"></line><line x1="8" x2="8" y1="2" y2="6"></line><line x1="3" x2="21" y1="10" y2="10"></line><path d="m9 16 2 2 4-4"></path></svg>
              </div>
              <h3 className="text-lg font-semibold text-center mb-2">
                Personalized Plans
              </h3>
              <p className="text-gray-600 text-center">
                Follow meal and workout schedules customized to your preferences and goals.
              </p>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="bg-gray-50 py-8 mt-12">
        <div className="container mx-auto px-4 text-center text-gray-500 text-sm">
          <p>© 2025 Tamil Fit Fusion. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
