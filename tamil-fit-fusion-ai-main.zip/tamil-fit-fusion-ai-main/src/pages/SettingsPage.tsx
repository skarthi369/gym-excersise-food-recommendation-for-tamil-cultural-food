
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import { useUser } from '@/context/UserContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';

const SettingsPage: React.FC = () => {
  const { resetProfile } = useUser();
  const navigate = useNavigate();
  
  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset your profile and plans? This action cannot be undone.')) {
      resetProfile();
      toast.success('Your profile and plans have been reset.');
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-lg mx-auto">
          <h1 className="text-2xl font-bold mb-6">Settings</h1>
          
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>Manage your account preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center py-2 border-b">
                <div>
                  <h3 className="font-medium">Reset Profile</h3>
                  <p className="text-sm text-gray-600">Clear all your profile data and generated plans</p>
                </div>
                <Button variant="destructive" size="sm" onClick={handleReset}>
                  Reset
                </Button>
              </div>
              
              <div className="flex justify-between items-center py-2 border-b">
                <div>
                  <h3 className="font-medium">About</h3>
                  <p className="text-sm text-gray-600">Tamil Fit Fusion v1.0</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <p className="text-xs text-gray-500">
                This app provides personalized Tamil cuisine and workout plans based on your fitness goals.
              </p>
            </CardFooter>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default SettingsPage;
