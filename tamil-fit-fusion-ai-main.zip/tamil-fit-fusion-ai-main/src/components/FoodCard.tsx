import React from 'react';
import { Food } from '@/data/models';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface FoodCardProps {
  food: Food;
  mealType?: string;
}

const MacroNutrient: React.FC<{ label: string; value: number; unit: string; color: string }> = ({ 
  label, value, unit, color 
}) => (
  <div className="flex flex-col items-center">
    <span className={`text-sm font-medium ${color}`}>{value}{unit}</span>
    <span className="text-xs text-gray-500">{label}</span>
  </div>
);

const FoodCard: React.FC<FoodCardProps> = ({ food, mealType }) => {
  const fallbackImage = 'https://images.unsplash.com/photo-1618160702438-9b02ab6515c9';

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card className="food-card hover:scale-in cursor-pointer overflow-hidden hover:shadow-md transition-all">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-lg">{food.name}</CardTitle>
            {mealType && (
              <CardDescription className="text-sm capitalize">{mealType}</CardDescription>
            )}
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="aspect-video w-full bg-gray-100 rounded-md mb-4 overflow-hidden">
              <img 
                src={food.imageUrl || fallbackImage}
                alt={food.name}
                className="w-full h-full object-cover transition-transform hover:scale-105"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = fallbackImage;
                }}
              />
            </div>
            <div className="flex justify-between items-center mt-2">
              <MacroNutrient 
                label="Calories" 
                value={food.calories} 
                unit="kcal" 
                color="text-orange-500" 
              />
              <MacroNutrient 
                label="Protein" 
                value={food.protein} 
                unit="g" 
                color="text-tamil-purple-600" 
              />
              <MacroNutrient 
                label="Carbs" 
                value={food.carbs} 
                unit="g" 
                color="text-tamil-green-600" 
              />
              <MacroNutrient 
                label="Fat" 
                value={food.fats} 
                unit="g" 
                color="text-yellow-500" 
              />
            </div>
          </CardContent>
          <CardFooter className="p-4 pt-0 flex justify-between">
            <Badge variant={food.isVegetarian ? "outline" : "secondary"} className="text-xs">
              {food.isVegetarian ? "Vegetarian" : food.isEggitarian ? "Eggetarian" : "Non-Veg"}
            </Badge>
            <Badge variant="outline" className="text-xs capitalize">
              {food.suitableFor.join(', ')}
            </Badge>
          </CardFooter>
        </Card>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{food.name}</DialogTitle>
          <DialogDescription>Detailed nutritional information and recipe.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="aspect-video w-full bg-gray-100 rounded-md overflow-hidden">
            <img 
              src={food.imageUrl || fallbackImage}
              alt={food.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = fallbackImage;
              }}
            />
          </div>
          <div className="grid grid-cols-4 gap-4 p-4 bg-gray-50 rounded-md">
            <MacroNutrient 
              label="Calories" 
              value={food.calories} 
              unit="kcal" 
              color="text-orange-500" 
            />
            <MacroNutrient 
              label="Protein" 
              value={food.protein} 
              unit="g" 
              color="text-tamil-purple-600" 
            />
            <MacroNutrient 
              label="Carbs" 
              value={food.carbs} 
              unit="g" 
              color="text-tamil-green-600" 
            />
            <MacroNutrient 
              label="Fat" 
              value={food.fats} 
              unit="g" 
              color="text-yellow-500" 
            />
          </div>
          <div>
            <h3 className="text-sm font-medium mb-2">Description</h3>
            <p className="text-sm text-gray-600">{food.description}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium mb-2">Ingredients</h3>
            <ul className="list-disc list-inside text-sm text-gray-600">
              {food.ingredients.map((ingredient, index) => (
                <li key={index}>{ingredient}</li>
              ))}
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default FoodCard;
