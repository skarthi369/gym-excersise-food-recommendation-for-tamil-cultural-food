import { Workout } from './models';

export const workouts: Workout[] = [
  {
    id: 1,
    name: 'Push-ups',
    muscleGroup: 'Chest, Shoulders, Triceps',
    level: ['beginner', 'intermediate', 'advanced'],
    instructions: [
      'Start in a plank position with hands shoulder-width apart.',
      'Lower your body until your chest nearly touches the floor.',
      'Push back up to the starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://www.inspireusafoundation.org/wp-content/uploads/2023/04/full-wrist-push-up-benefits.png',
    suitableFor: ['bulking', 'cutting'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 2,
    name: 'Squats',
    muscleGroup: 'Quadriceps, Hamstrings, Glutes',
    level: ['beginner', 'intermediate', 'advanced'],
    instructions: [
      'Stand with feet shoulder-width apart.',
      'Lower your body by bending your knees and pushing your hips back.',
      'Keep your chest up and back straight.',
      'Return to the starting position by pushing through your heels.'
    ],
    imageUrl: 'https://www.inspireusafoundation.org/wp-content/uploads/2022/07/bodyweight-wall-squat-1024x754.png',
    suitableFor: ['bulking', 'cutting'],
    duration: 20,
    sets: 4,
    reps: 15
  },
  {
    id: 3,
    name: 'Dumbbell Rows',
    muscleGroup: 'Back, Biceps',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Place one knee and hand on a bench.',
      'Hold a dumbbell in the other hand, arm extended.',
      'Pull the dumbbell up to your hip, keeping your elbow close to your body.',
      'Lower the dumbbell back to the starting position.'
    ],
    imageUrl: 'https://www.burnthefatinnercircle.com/members/images/1581c.jpg',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 4,
    name: 'Lunges',
    muscleGroup: 'Quadriceps, Hamstrings, Glutes',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Stand with feet hip-width apart.',
      'Step forward with one leg and lower your body until both knees are bent at 90 degrees.',
      'Push through the front heel to return to the starting position.',
      'Repeat with the other leg.'
    ],
    imageUrl: 'https://wellness52.com/wp-content/uploads/2022/12/Lunge.jpg',
    suitableFor: ['cutting', 'bulking'],
    duration: 15,
    sets: 3,
    reps: 10
  },
  {
    id: 5,
    name: 'Bench Press',
    muscleGroup: 'Chest, Shoulders, Triceps',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Lie on a bench with feet flat on the floor.',
      'Grip the barbell with hands slightly wider than shoulder-width apart.',
      'Lower the bar to your chest, then push it back up to the starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse4.mm.bing.net/th?id=OIP.8097oWBTDInfGglJfXZZzgHaEk&pid=Api&P=0&h=180',
    suitableFor: ['bulking'],
    duration: 20,
    sets: 4,
    reps: 8
  },
  {
    id: 6,
    name: 'Plank',
    muscleGroup: 'Core, Shoulders',
    level: ['beginner', 'intermediate', 'advanced'],
    instructions: [
      'Start in a push-up position but with your weight on your forearms.',
      'Keep your body in a straight line from head to heels.',
      'Engage your core and hold the position.',
      'Hold for the prescribed time.'
    ],
    imageUrl: 'https://www.inspireusafoundation.org/wp-content/uploads/2022/11/body-saw-plank-benefits.jpg',
    suitableFor: ['cutting', 'bulking'],
    duration: 10,
    sets: 3,
    reps: 1
  },
  {
    id: 7,
    name: 'Deadlift',
    muscleGroup: 'Back, Glutes, Hamstrings',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Stand with feet hip-width apart, barbell over midfoot.',
      'Bend at hips and knees to lower hands to bar, keeping back flat.',
      'Grip bar with hands shoulder-width apart.',
      'Drive through heels to stand up, keeping barbell close to body.'
    ],
    imageUrl: 'https://liftmanual.com/wp-content/uploads/2023/04/barbell-stiff-legged-deadlift.jpg',
    suitableFor: ['bulking'],
    duration: 25,
    sets: 4,
    reps: 6
  },
  {
    id: 8,
    name: 'HIIT Sprint Intervals',
    muscleGroup: 'Full Body, Cardiovascular',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Warm up with light jogging for 5 minutes.',
      'Sprint at maximum effort for 30 seconds.',
      'Recover with slow jogging or walking for 90 seconds.',
      'Repeat for 8-10 rounds.'
    ],
    imageUrl: 'https://as2.ftcdn.net/v2/jpg/02/98/05/75/1000_F_298057529_3vHp9X8VzIMgqCfrkdKpMoxSCc37fztZ.jpg',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 8,
    reps: 1
  },
  {
    id: 9,
    name: 'Bicep Curls',
    muscleGroup: 'Biceps',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Stand with dumbbells at your sides.',
      'Curl the weights up towards your shoulders.',
      'Lower the weights slowly back to the starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://www.inspireusafoundation.org/wp-content/uploads/2023/04/dumbbell-curl-benefits.png',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 3,
    reps: 14
  },
  {
    id: 10,
    name: 'Tricep Dips',
    muscleGroup: 'Triceps',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Place your hands on a bench or chair behind you.',
      'Lower your body by bending your elbows to 90 degrees.',
      'Push back up to the starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse3.mm.bing.net/th?id=OIP.rdjlQTf9PAT6M-G3w-VYHgHaDX&pid=Api&P=0&h=180',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 4,
    reps: 12
  },
  {
    id: 11,
    name: 'Leg Press',
    muscleGroup: 'Quadriceps, Hamstrings, Glutes',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Sit on the leg press machine with feet shoulder-width apart on the platform.',
      'Push the platform away by extending your legs.',
      'Slowly return to the starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse2.mm.bing.net/th?id=OIP.ZUAkcY76_Z-vbmPMRCtfRQHaDH&pid=Api&P=0&h=180',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 3,
    reps: 15
  },
  {
    id: 12,
    name: 'Calf Raises',
    muscleGroup: 'Calves',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Stand with feet hip-width apart.',
      'Raise your heels off the ground as high as possible.',
      'Lower your heels back down slowly.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse1.mm.bing.net/th?id=OIP.uuUAm5PjLnMnBdXc7hG_TwHaGz&pid=Api&P=0&h=180',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 13
  },
  {
    id: 13,
    name: 'Shoulder Press',
    muscleGroup: 'Shoulders',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Hold dumbbells at shoulder height with palms facing forward.',
      'Press the weights overhead until arms are fully extended.',
      'Lower the weights back to shoulder height.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://homegymreview.co.uk/wp-content/uploads/exercises/35471101-Dumbbell-Seated-Biceps-Curl-to-Shoulder-Press_Shoulders_max-scaled.jpg',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 4,
    reps: 12
  },
  {
    id: 14,
    name: 'Chest Fly',
    muscleGroup: 'Chest',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Lie on a bench holding dumbbells above your chest with arms extended.',
      'Lower the weights out to the sides, keeping a slight bend in your elbows.',
      'Bring the weights back together above your chest.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://global-uploads.webflow.com/5d1d0d3f53ced35a29dbe169/5e2a552a38b3bd766a0167ff_incline-dumbbell-fly-exercise-anabolic-aliens.png',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 15,
    name: 'Lat Pulldown',
    muscleGroup: 'Back',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Sit at the lat pulldown machine and grip the bar wider than shoulder width.',
      'Pull the bar down to your upper chest.',
      'Slowly release the bar back up.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse3.mm.bing.net/th?id=OIP.sxJnLPQ0NnHbiFk7RHEP4wHaFx&pid=Api&P=0&h=180',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 4,
    reps: 12
  },
  {
    id: 16,
    name: 'Seated Row',
    muscleGroup: 'Back, Biceps',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Sit at the rowing machine and grab the handles.',
      'Pull the handles towards your torso, squeezing your shoulder blades together.',
      'Slowly release the handles forward.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://liftmanual.com/wp-content/uploads/2023/04/cable-rope-seated-row.jpg',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 17,
    name: 'Russian Twists',
    muscleGroup: 'Core',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Sit on the floor with knees bent and feet lifted slightly.',
      'Lean back slightly and twist your torso to the right, then to the left.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://www.endomondo.com/wp-content/uploads/2024/01/Russian-Twist.jpg',
    suitableFor: ['cutting'],
    duration: 15,
    sets: 3,
    reps: 20
  },
  {
    id: 18,
    name: 'Mountain Climbers',
    muscleGroup: 'Full Body, Cardiovascular',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Start in a plank position.',
      'Bring one knee towards your chest, then switch legs quickly.',
      'Continue alternating legs at a fast pace.',
      'Repeat for the prescribed time.'
    ],
    imageUrl: 'https://liftmanual.com/wp-content/uploads/2023/04/mountain-climber.jpg',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 30
  },
  {
    id: 19,
    name: 'Burpees',
    muscleGroup: 'Full Body, Cardiovascular',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Start standing, then squat and place your hands on the floor.',
      'Jump your feet back into a plank position.',
      'Jump your feet forward to your hands and explode up into a jump.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://i0.wp.com/muscu-street-et-crossfit.fr/wp-content/uploads/2022/12/Muscles-burpees.003.jpeg?resize=1024%2C576&ssl=1',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 4,
    reps: 15
  },
  {
    id: 20,
    name: 'Jumping Jacks',
    muscleGroup: 'Full Body, Cardiovascular',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Stand with feet together and arms at your sides.',
      'Jump feet out while raising arms overhead.',
      'Jump back to starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://www.inspireusafoundation.org/wp-content/uploads/2022/07/jumping-jacks-muscles-1536x1067.png',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 30
  },
  {
    id: 21,
    name: 'Leg Raises',
    muscleGroup: 'Core',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Lie on your back with legs straight.',
      'Lift your legs up to 90 degrees.',
      'Lower your legs slowly without touching the floor.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://liftmanual.com/wp-content/uploads/2023/04/criss-cross-leg-raises.jpg',
    suitableFor: ['cutting'],
    duration: 15,
    sets: 3,
    reps: 15
  },
  {
    id: 22,
    name: 'Glute Bridges',
    muscleGroup: 'Glutes, Hamstrings',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Lie on your back with knees bent and feet flat on the floor.',
      'Lift your hips off the ground by squeezing your glutes.',
      'Hold briefly and lower back down.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse1.mm.bing.net/th?id=OIP.JjgFncz4I5fueNAufwpJzgHaCL&pid=Api&P=0&h=180',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 23,
    name: 'Cable Crossovers',
    muscleGroup: 'Chest',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Stand between two cable machines holding handles.',
      'Bring hands together in front of your chest.',
      'Slowly return to starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse4.mm.bing.net/th?id=OIP.9idEXAbC1o72xe3Gg2ZObgHaEk&pid=Api&P=0&h=180',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 4,
    reps: 12
  },
  {
    id: 24,
    name: 'Hammer Curls',
    muscleGroup: 'Biceps',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Hold dumbbells with palms facing your torso.',
      'Curl the weights while keeping palms facing in.',
      'Lower slowly to starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://www.inspireusafoundation.org/wp-content/uploads/2023/06/cross-body-hammer-curl-muscles-1024x912.png',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 25,
    name: 'Front Raises',
    muscleGroup: 'Shoulders',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Hold dumbbells in front of your thighs.',
      'Raise weights to shoulder height with straight arms.',
      'Lower slowly to starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://justfitnesshub.com/wp-content/uploads/2021/04/DFR-599388.jpg',
    suitableFor: ['cutting'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 26,
    name: 'Side Planks',
    muscleGroup: 'Core',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Lie on one side, supporting your body on your forearm.',
      'Keep your body in a straight line and hold the position.',
      'Switch sides and repeat.',
      'Hold for the prescribed time.'
    ],
    imageUrl: 'https://liftmanual.com/wp-content/uploads/2023/04/side-plank.jpg',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 1
  },
  {
    id: 27,
    name: 'Box Jumps',
    muscleGroup: 'Legs, Cardiovascular',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Stand in front of a sturdy box or platform.',
      'Jump onto the box with both feet.',
      'Step down carefully and repeat.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://www.endomondo.com/wp-content/uploads/2024/01/Box-Jump.jpg',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 4,
    reps: 10
  },
  {
    id: 28,
    name: 'Kettlebell Swings',
    muscleGroup: 'Full Body, Cardiovascular',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Hold a kettlebell with both hands.',
      'Swing it between your legs and then up to shoulder height.',
      'Use hip thrusts to generate momentum.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://liftmanual.com/wp-content/uploads/2023/04/kettlebell-one-arm-swing.jpg',
    suitableFor: ['bulking'],
    duration: 20,
    sets: 4,
    reps: 15
  },
  {
    id: 29,
    name: 'Wall Sits',
    muscleGroup: 'Quadriceps',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Lean against a wall with feet shoulder-width apart.',
      'Slide down until knees are at 90 degrees.',
      'Hold the position for the prescribed time.',
      'Repeat for the prescribed number of sets.'
    ],
    imageUrl: 'https://tse3.mm.bing.net/th?id=OIP.cxUcDXeXKKqCQ3OcEO54QQHaFZ&pid=Api&P=0&h=180',
    suitableFor: ['cutting'],
    duration: 15,
    sets: 3,
    reps: 1
  },
  {
    id: 30,
    name: 'Step-ups',
    muscleGroup: 'Legs, Glutes',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Step onto a bench or platform with one foot.',
      'Push through the heel to lift your body up.',
      'Step down and repeat with the other leg.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse1.mm.bing.net/th?id=OIP.FayXVKB2s1cs6bGPgQKWtQHaEK&pid=Api&P=0&h=180',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 31,
    name: 'Incline Bench Press',
    muscleGroup: 'Chest, Shoulders, Triceps',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Lie on an incline bench with feet flat on the floor.',
      'Grip the barbell slightly wider than shoulder-width.',
      'Lower the bar to your upper chest.',
      'Push the bar back up to the starting position.'
    ],
    imageUrl: 'https://tse2.mm.bing.net/th?id=OIP.Ve9BMm_E06JcAXpdbQeRTwHaFS&pid=Api&P=0&h=180',
    suitableFor: ['bulking'],
    duration: 20,
    sets: 4,
    reps: 8
  },
  {
    id: 32,
    name: 'Decline Bench Press',
    muscleGroup: 'Chest, Shoulders, Triceps',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Lie on a decline bench with feet secured.',
      'Grip the barbell slightly wider than shoulder-width.',
      'Lower the bar to your lower chest.',
      'Push the bar back up to the starting position.'
    ],
    imageUrl: 'https://www.hevyapp.com/wp-content/uploads/03011201-Dumbbell-Decline-Bench-Press_Chest.jpg',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 4,
    reps: 8
  },
  {
    id: 33,
    name: 'Cable Rows',
    muscleGroup: 'Back, Biceps',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Sit at the cable row machine and grip the handles.',
      'Pull handles towards your torso, squeezing shoulder blades.',
      'Slowly release to starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://fitliferegime.com/wp-content/uploads/2023/03/Seated-Cable-Row.jpg',
    suitableFor: ['bulking'],
    duration: 20,
    sets: 4,
    reps: 12
  },
  {
    id: 34,
    name: 'Face Pulls',
    muscleGroup: 'Shoulders, Upper Back',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Attach a rope to a cable pulley at face height.',
      'Pull the rope towards your face, keeping elbows high.',
      'Squeeze shoulder blades together.',
      'Slowly return to starting position.'
    ],
    imageUrl: 'https://daily-fit.fr/wp-content/uploads/2024/01/muscles-face-pull-dailyfit-jpeg.webp',
    suitableFor: ['cutting'],
    duration: 15,
    sets: 3,
    reps: 15
  },
  {
    id: 35,
    name: 'Reverse Flys',
    muscleGroup: 'Shoulders, Upper Back',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Hold dumbbells and bend at the hips.',
      'Raise arms out to the sides, squeezing shoulder blades.',
      'Lower weights back down.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://homegymreview.co.uk/wp-content/uploads/exercises/06021101-Lever-Seated-Reverse-Fly_Shoulders_max-scaled.jpg',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 36,
    name: 'Hip Thrusts',
    muscleGroup: 'Glutes, Hamstrings',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Sit on the floor with upper back against a bench.',
      'Place a barbell over your hips.',
      'Thrust hips upward, squeezing glutes at the top.',
      'Lower hips back down and repeat.'
    ],
    imageUrl: 'https://doriangym.es/wp-content/uploads/2022/10/como-se-hace-hip-thrust.jpg',
    suitableFor: ['bulking'],
    duration: 20,
    sets: 4,
    reps: 12
  },
  {
    id: 37,
    name: "Farmer's Walk",
    muscleGroup: 'Full Body',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Hold heavy dumbbells or kettlebells at your sides.',
      'Walk forward keeping your back straight and core engaged.',
      'Continue for the prescribed distance or time.'
    ],
    imageUrl: 'https://ginasiovirtual.com/wp-content/uploads/2021/06/Farmers-Walk.jpg',
    suitableFor: ['cutting'],
    duration: 15,
    sets: 3,
    reps: 1
  },
  {
    id: 38,
    name: 'Medicine Ball Slams',
    muscleGroup: 'Full Body, Core',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Hold a medicine ball overhead.',
      'Slam the ball forcefully onto the ground.',
      'Catch the ball on the bounce and repeat.'
    ],
    imageUrl: 'https://tse1.mm.bing.net/th?id=OIP.pFGhG4UkTTI2j_pQwo95rgHaFm&pid=Api&P=0&h=180',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 15
  },
  {
    id: 39,
    name: 'Battle Ropes',
    muscleGroup: 'Full Body, Cardiovascular',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Hold the ends of battle ropes.',
      'Create waves by moving your arms up and down rapidly.',
      'Maintain a strong stance and core engagement.'
    ],
    imageUrl: 'https://tse1.mm.bing.net/th?id=OIP._NJ_U4ZoOM7hZNe6cLAH7gHaHa&pid=Api&P=0&h=180',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 4,
    reps: 30
  },
  {
    id: 40,
    name: 'Tire Flips',
    muscleGroup: 'Full Body, Strength',
    level: ['advanced'],
    instructions: [
      'Squat down and grip the bottom of a large tire.',
      'Use your legs and arms to flip the tire forward.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse1.mm.bing.net/th?id=OIP.nab_RBzrNmiuonn0Af4bZgHaDI&pid=Api&P=0&h=180',
    suitableFor: ['bulking'],
    duration: 25,
    sets: 4,
    reps: 6
  },
  {
    id: 41,
    name: 'Sled Push',
    muscleGroup: 'Full Body, Strength',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Load weight on a sled.',
      'Push the sled forward using your legs and core.',
      'Repeat for the prescribed distance or time.'
    ],
    imageUrl: 'https://tse3.mm.bing.net/th?id=OIP.1EZ2GHEDCaCQ_CI9LY4cVwHaEK&pid=Api&P=0&h=180',
    suitableFor: ['bulking'],
    duration: 20,
    sets: 4,
    reps: 10
  },
  {
    id: 42,
    name: 'Sled Pull',
    muscleGroup: 'Full Body, Strength',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Attach a harness or rope to a sled.',
      'Pull the sled backward using your legs and core.',
      'Repeat for the prescribed distance or time.'
    ],
    imageUrl: 'https://tse2.mm.bing.net/th?id=OIP.D5_RzUWw4WTqI4S7jBaF9wHaHa&pid=Api&P=0&h=180',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 4,
    reps: 10
  },
  {
    id: 43,
    name: 'Pistol Squats',
    muscleGroup: 'Quadriceps, Hamstrings, Glutes',
    level: ['advanced'],
    instructions: [
      'Stand on one leg with the other leg extended forward.',
      'Lower your body into a squat on the standing leg.',
      'Push back up to the starting position.',
      'Alternate legs and repeat.'
    ],
    imageUrl: 'https://tse2.mm.bing.net/th?id=OIP.QHsnqJP4XvW20AGyZVuoXAHaEK&pid=Api&P=0&h=180',
    suitableFor: ['cutting'],
    duration: 20,
    sets: 4,
    reps: 8
  },
  {
    id: 44,
    name: 'Clap Push-ups',
    muscleGroup: 'Chest, Shoulders, Triceps',
    level: ['advanced'],
    instructions: [
      'Start in a push-up position.',
      'Push explosively off the ground to clap your hands.',
      'Land softly and immediately go into the next push-up.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://liftmanual.com/wp-content/uploads/2023/04/clap-push-up.jpg',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 45,
    name: 'Diamond Push-ups',
    muscleGroup: 'Chest, Shoulders, Triceps',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Place hands close together under your chest, forming a diamond shape.',
      'Lower your body until your chest nearly touches your hands.',
      'Push back up to the starting position.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse4.mm.bing.net/th?id=OIP.O3C0uxuGoFwcY03DQFYspAHaHa&pid=Api&P=0&h=180',
    suitableFor: ['cutting'],
    duration: 15,
    sets: 3,
    reps: 12
  },
  {
    id: 46,
    name: 'Handstand Hold',
    muscleGroup: 'Shoulders, Core',
    level: ['advanced'],
    instructions: [
      'Kick up into a handstand against a wall.',
      'Engage your core and hold the position.',
      'Hold for the prescribed time.'
    ],
    imageUrl: 'https://tse1.mm.bing.net/th?id=OIP._NrMdjPLKlHcnP5_heviMwAAAA&pid=Api&P=0&h=180',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 1
  },
  {
    id: 47,
    name: 'Tuck Jumps',
    muscleGroup: 'Legs, Cardiovascular',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Jump straight up, bringing your knees to your chest.',
      'Land softly and immediately jump again.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://tse2.mm.bing.net/th?id=OIP.GkdR8i4UzjgabAcuYjU1cwHaD4&pid=Api&P=0&h=180',
    suitableFor: ['cutting'],
    duration: 15,
    sets: 3,
    reps: 15
  },
  {
    id: 48,
    name: 'Skater Jumps',
    muscleGroup: 'Legs, Cardiovascular',
    level: ['intermediate', 'advanced'],
    instructions: [
      'Jump laterally from one foot to the other.',
      'Land softly and immediately jump to the other side.',
      'Repeat for the prescribed number of repetitions.'
    ],
    imageUrl: 'https://liftmanual.com/wp-content/uploads/2023/04/skater-hops.jpg',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
    reps: 20
  },
  {
    id: 49,
    name: 'Bear Crawls',
    muscleGroup: 'Full Body, Core',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Start on hands and feet with hips low.',
      'Move forward by crawling with opposite hand and foot.',
      'Continue for the prescribed distance or time.'
    ],
    imageUrl: 'https://tse1.mm.bing.net/th?id=OIP.sh5Ce5VzdQO5WvKg_OwWqAHaEK&pid=Api&P=0&h=180',
    suitableFor: ['cutting'],
    duration: 15,
    sets: 3,
    reps: 30
  },
  {
    id: 50,
    name: 'Plank Shoulder Taps',
    muscleGroup: 'Core, Shoulders',
    level: ['beginner', 'intermediate'],
    instructions: [
      'Start in a plank position.',
      'Tap your left shoulder with your right hand.',
      'Return hand to the floor and tap your right shoulder with your left hand.',
      'Continue alternating taps.'
    ],
    imageUrl: 'https://liftmanual.com/wp-content/uploads/2023/04/shoulder-tap.jpg',
    suitableFor: ['bulking'],
    duration: 15,
    sets: 3,
  reps: 20
}
];