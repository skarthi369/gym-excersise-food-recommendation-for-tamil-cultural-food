
import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, DailyPlan, FitnessGoal, FoodPreference, FitnessLevel } from '../data/models';
import { generateSamplePlans } from '../data/mockData';

interface UserContextType {
  userProfile: UserProfile | null;
  dailyPlans: DailyPlan[];
  isProfileComplete: boolean;
  updateProfile: (profile: Partial<UserProfile>) => void;
  resetProfile: () => void;
  generatePlans: () => void;
}

const initialProfile: UserProfile = {
  goal: 'bulking',
  foodPreference: 'vegetarian',
  fitnessLevel: 'beginner',
  scheduleDuration: 30
};

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [dailyPlans, setDailyPlans] = useState<DailyPlan[]>([]);
  const [isProfileComplete, setIsProfileComplete] = useState(false);

  // Load profile from localStorage on mount
  useEffect(() => {
    const storedProfile = localStorage.getItem('userProfile');
    if (storedProfile) {
      try {
        setUserProfile(JSON.parse(storedProfile));
      } catch (error) {
        console.error('Failed to parse stored profile:', error);
      }
    }

    const storedPlans = localStorage.getItem('dailyPlans');
    if (storedPlans) {
      try {
        setDailyPlans(JSON.parse(storedPlans));
      } catch (error) {
        console.error('Failed to parse stored plans:', error);
      }
    }
  }, []);

  // Update localStorage when profile changes
  useEffect(() => {
    if (userProfile) {
      localStorage.setItem('userProfile', JSON.stringify(userProfile));
      // Check if profile is complete
      const { goal, foodPreference, fitnessLevel, scheduleDuration } = userProfile;
      setIsProfileComplete(!!goal && !!foodPreference && !!fitnessLevel && !!scheduleDuration);
    } else {
      localStorage.removeItem('userProfile');
      setIsProfileComplete(false);
    }
  }, [userProfile]);

  // Update localStorage when plans change
  useEffect(() => {
    if (dailyPlans.length > 0) {
      localStorage.setItem('dailyPlans', JSON.stringify(dailyPlans));
    }
  }, [dailyPlans]);

  const updateProfile = (profile: Partial<UserProfile>) => {
    setUserProfile(prev => {
      if (!prev) return { ...initialProfile, ...profile };
      return { ...prev, ...profile };
    });
  };

  const resetProfile = () => {
    setUserProfile(null);
    setDailyPlans([]);
    localStorage.removeItem('userProfile');
    localStorage.removeItem('dailyPlans');
  };

  const generatePlans = () => {
    if (!userProfile) return;
    
    const plans = generateSamplePlans(
      userProfile.goal, 
      userProfile.foodPreference, 
      userProfile.scheduleDuration
    );
    
    setDailyPlans(plans);
  };

  return (
    <UserContext.Provider
      value={{
        userProfile,
        dailyPlans,
        isProfileComplete,
        updateProfile,
        resetProfile,
        generatePlans
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};
